@echo off
setlocal
cd /d "%~dp0"
if /i "%~1"=="--hidden" goto run
set "SERVER_BOOT_BAT=%~f0"
powershell.exe -NoProfile -Command "$a='/d /s /c '+[char]34+[char]34+$env:SERVER_BOOT_BAT+[char]34+' --hidden'+[char]34; Start-Process -FilePath $env:ComSpec -ArgumentList $a -WindowStyle Hidden"
if errorlevel 1 (
 echo Hidden launch failed. Press any key to run here.
 pause >nul
 goto run
)
exit /b
:run
if not exist "lib\server.jar" (
 echo lib\server.jar not found. > "server_startup.log"
 start "" notepad.exe "%~dp0server_startup.log"
 exit /b 2
)
powershell.exe -NoProfile -Command "$p=Get-CimInstance Win32_Process | Where-Object {$_.Name -match '^javaw?\.exe$' -and $_.CommandLine -match 'lineage\.Main'}; if($p){Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show('The server is already running. Close it before restarting.','Server'); exit 10}"
if errorlevel 1 exit /b
where java > "server_startup.log" 2>&1
java -version >> "server_startup.log" 2>&1
java -Xms2g -Xmx8g -cp lib/HikariCP-2.6.2.jar;lib/json-simple-1.1.1.jar;lib/log4j-1.2.16.jar;lib/mchange-commons-java-0.2.3.jar;lib/mysql-connector-java-5.1.49.jar;lib/netty-3.9.9.Final.jar;lib/org.eclipse.swt.win32.win32.x86_64_3.7.1.v3738a.jar;lib/slf4j-api-1.6.1.jar;lib/slf4j-log4j12-1.6.1.jar;lib/swt-3.5.1-win32-win32-x86.jar;lib/server.jar lineage.Main >> "server_startup.log" 2>&1
set "SERVER_EXIT=%errorlevel%"
if not "%SERVER_EXIT%"=="0" (
 powershell.exe -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show('Server startup failed. See server_startup.log.','Server')"
 start "" notepad.exe "%~dp0server_startup.log"
)
exit /b %SERVER_EXIT%
