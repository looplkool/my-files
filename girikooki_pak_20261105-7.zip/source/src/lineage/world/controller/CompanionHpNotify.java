package lineage.world.controller;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import lineage.world.object.instance.SummonInstance;
import lineage.world.object.object;
import lineage.bean.lineage.Summon;
import lineage.network.packet.BasePacketPooling;
import lineage.network.packet.server.S_ObjectHitratio;

/** Sends growth HP notifications without holding AccountCompanion's monitor. */
public final class CompanionHpNotify extends Thread {
    private static final LinkedBlockingQueue<SummonInstance> QUEUE = new LinkedBlockingQueue<SummonInstance>();
    private static final ConcurrentHashMap<SummonInstance, Boolean> PENDING = new ConcurrentHashMap<SummonInstance, Boolean>();
    static { new CompanionHpNotify().start(); }
    private CompanionHpNotify() { super("CompanionHpNotify"); setDaemon(true); }
    public static void defer(SummonInstance pet) {
        if (PENDING.putIfAbsent(pet, Boolean.TRUE) == null) QUEUE.add(pet);
    }
    public void run() {
        for (;;) {
            SummonInstance pet;
            try { pet = QUEUE.take(); }
            catch (InterruptedException e) { continue; }
            try {
                Summon summon = pet.getSummon();
                object master = summon == null ? null : summon.getMaster();
                if (master != null) {
                    // Wait for the owner before constructing the packet. No companion
                    // monitor is held here; read current HP to coalesce notifications.
                    synchronized (master) {
                        if (!pet.isWorldDelete() && pet.getSummon() == summon && summon.getMaster() == master)
                            master.toSender(S_ObjectHitratio.clone(BasePacketPooling.getPool(S_ObjectHitratio.class), pet, true));
                    }
                }
            } catch (Exception e) {
                System.err.println("[CompanionHpNotify] " + e);
            } finally { PENDING.remove(pet); }
        }
    }
}
