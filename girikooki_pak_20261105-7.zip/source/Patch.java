import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;
public class Patch {
 public static void main(String[] args) throws Exception {
  String target="lineage/world/object/instance/SummonInstance.class";
  try(ZipFile z=new ZipFile(args[0]);ZipOutputStream out=new ZipOutputStream(Files.newOutputStream(Paths.get(args[1])))) {
   Enumeration<? extends ZipEntry> es=z.entries();int changed=0;
   while(es.hasMoreElements()) {
    ZipEntry e=es.nextElement(); byte[] b=z.getInputStream(e).readAllBytes();
    if(e.getName().equals(target)) {
     ClassNode c=new ClassNode();new ClassReader(b).accept(c,0);
     for(MethodNode m:c.methods) if(m.name.equals("setNowHp") && m.desc.equals("(I)V")) {
      for(AbstractInsnNode n:m.instructions.toArray()) if(n instanceof MethodInsnNode && n.getOpcode()==Opcodes.INVOKESPECIAL && ((MethodInsnNode)n).name.equals("setNowHp")) {
       InsnList p=new InsnList();LabelNode normal=new LabelNode();
       p.add(new VarInsnNode(Opcodes.ALOAD,0));p.add(new TypeInsnNode(Opcodes.INSTANCEOF,"lineage/world/object/instance/AccountCompanionInstance"));p.add(new JumpInsnNode(Opcodes.IFEQ,normal));
       p.add(new LdcInsnNode(Type.getObjectType("lineage/world/controller/AccountCompanion")));p.add(new MethodInsnNode(Opcodes.INVOKESTATIC,"java/lang/Thread","holdsLock","(Ljava/lang/Object;)Z",false));p.add(new JumpInsnNode(Opcodes.IFEQ,normal));
       p.add(new FieldInsnNode(Opcodes.GETSTATIC,"lineage/share/Lineage","server_version","I"));p.add(new IntInsnNode(Opcodes.SIPUSH,144));p.add(new JumpInsnNode(Opcodes.IF_ICMPLE,normal));
       p.add(new VarInsnNode(Opcodes.ALOAD,0));p.add(new MethodInsnNode(Opcodes.INVOKESTATIC,"lineage/world/controller/CompanionHpNotify","defer","(Llineage/world/object/instance/SummonInstance;)V",false));p.add(new InsnNode(Opcodes.RETURN));p.add(normal);
       // Original class predates stack maps. Explicit same frame keeps newer verifier valid.
       p.add(new FrameNode(Opcodes.F_SAME,0,null,0,null));
       m.instructions.insert(n,p);changed++;
      }
     }
     ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);b=w.toByteArray();
    }
    ZipEntry ne=new ZipEntry(e.getName());ne.setTime(e.getTime());out.putNextEntry(ne);out.write(b);out.closeEntry();
   }
   if(changed!=1)throw new IllegalStateException("Unexpected patch sites: "+changed);
   Path root=Paths.get(args[2]);for(Path f:(Iterable<Path>)Files.walk(root).filter(Files::isRegularFile)::iterator) {out.putNextEntry(new ZipEntry(root.relativize(f).toString()));out.write(Files.readAllBytes(f));out.closeEntry();}
  }
 }
}
