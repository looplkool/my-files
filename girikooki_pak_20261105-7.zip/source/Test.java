import lineage.world.object.instance.*;
import lineage.world.controller.*;
import lineage.bean.lineage.Summon;
import lineage.network.packet.BasePacket;
import lineage.share.Lineage;
import java.lang.reflect.*;
import java.util.concurrent.*;
import sun.misc.Unsafe;
public class Test {
 static Unsafe u; static int checks;
 public static class Owner extends PcInstance {
  public volatile int sends; public volatile boolean badLock;
  public Owner(){super(null);}
  public synchronized void toSender(BasePacket p){sends++;badLock|=Thread.holdsLock(AccountCompanion.class);}
 }
 static void ok(boolean b,String n){if(!b)throw new AssertionError(n);checks++;System.out.println("PASS "+n);}
 static void field(Object x,Class<?> c,String name,Object v)throws Exception {Field f=c.getDeclaredField(name);f.setAccessible(true);f.set(x,v);}
 static SummonInstance pet(Class<? extends SummonInstance> cls,Owner owner)throws Exception {
  SummonInstance p=(SummonInstance)u.allocateInstance(cls);
  for(Class<?> c=p.getClass();c!=null;c=c.getSuperclass())for(Field sf:c.getDeclaredFields())if(sf.getName().startsWith("sync_")&&sf.getType()==Object.class){sf.setAccessible(true);sf.set(p,new Object());}
  field(p,lineage.world.object.Character.class,"sync_hp",new Object());
  field(p,lineage.world.object.Character.class,"sync_mp",new Object());
  p.setMaxHp(200);p.setWorldDelete(false);
  Summon s=new Summon();field(s,Summon.class,"master",owner);
  p.setSummon(s);return p;
 }
 public static void main(String[] args)throws Exception {
  Field f=Unsafe.class.getDeclaredField("theUnsafe");f.setAccessible(true);u=(Unsafe)f.get(null);
  Lineage.server_version=200;Lineage.is_sync=true;
  Owner owner=(Owner)u.allocateInstance(Owner.class);
  SummonInstance p=pet(AccountCompanionInstance.class,owner);
  // Reproduce owner -> companion and companion -> owner inversion deterministically.
  CountDownLatch heldOwner=new CountDownLatch(1), heldCompanion=new CountDownLatch(1), doneSave=new CountDownLatch(1);
  Thread earn=new Thread(()->{synchronized(owner){heldOwner.countDown();try{heldCompanion.await();}catch(Exception e){throw new RuntimeException(e);}synchronized(AccountCompanion.class){}}},"test-earn");
  Thread save=new Thread(()->{try{heldOwner.await();synchronized(AccountCompanion.class){heldCompanion.countDown();p.setNowHp(170);doneSave.countDown();}}catch(Exception e){throw new RuntimeException(e);}},"test-save");
  earn.setDaemon(true);save.setDaemon(true);earn.start();save.start();
  boolean finished=doneSave.await(3,TimeUnit.SECONDS);
  if(args.length>0 && args[0].equals("baseline")){ok(!finished,"original reproduces owner/companion deadlock");return;}
  ok(finished,"HP save completes while owner is locked");earn.join(2000);save.join(2000);
  ok(!earn.isAlive()&&!save.isAlive(),"both competing threads finish");ok(p.getNowHp()==170,"HP update applied immediately");
  for(int i=0;i<100&&owner.sends==0;i++)Thread.sleep(10);
  ok(owner.sends>0,"deferred native HP notification arrives");ok(!owner.badLock,"notification never holds companion monitor");
  int n=owner.sends;p.setNowHp(160);ok(owner.sends==n+1,"normal companion damage sends synchronously");
  SummonInstance ordinary=pet(SummonInstance.class,owner);n=owner.sends;
  synchronized(AccountCompanion.class){ordinary.setNowHp(150);ok(owner.sends==n+1,"ordinary summon retains native behavior");}
  owner.badLock=false; // previous ordinary path intentionally holds the monitor
  Lineage.server_version=144;n=owner.sends;synchronized(AccountCompanion.class){p.setNowHp(140);}Thread.sleep(40);ok(owner.sends==n,"1.44 native no-notification behavior preserved");
  Lineage.server_version=200;
  synchronized(owner){synchronized(AccountCompanion.class){for(int i=0;i<10000;i++)p.setNowHp(130);}
    Class<?> h=Class.forName("lineage.world.controller.CompanionHpNotify");Field pf=h.getDeclaredField("PENDING");pf.setAccessible(true);ok(((java.util.Map)pf.get(null)).size()<=1,"10000 notifications coalesce for blocked owner");}
  for(int i=0;i<100&&p.getNowHp()!=130;i++)Thread.sleep(10);ok(p.getNowHp()==130,"repeated updates preserve latest HP");
  System.out.println("CHECKS "+checks);
 }
}
